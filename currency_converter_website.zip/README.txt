CURRENCYSIMPLE WEBSITE STARTER

1. Upload these files to a static website host (for example, GitHub Pages, Netlify, or another host you control).
2. Choose a domain and replace YOUR-DOMAIN.example in index.html, robots.txt, and sitemap.xml with your real domain.
3. Update the site name, contact details, and privacy policy to match your real setup.
4. Test the converter after publishing. It uses the Frankfurter public rate API and needs an internet connection.
5. Set up Google Search Console, verify your domain, and submit sitemap.xml.
6. Apply for Google AdSense at https://adsense.google.com/ only after the site is live and has useful original content, accurate policies, and a working contact method.

This is a starter site, not a guarantee of search ranking or AdSense approval. The owner must register accounts and submit the site personally.
